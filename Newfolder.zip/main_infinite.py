import os
import random
import binascii
import logging
from eth_keys import keys
from web3 import Web3
from time import sleep

# Configure logging
logging.basicConfig(filename="wallet_checker.log", level=logging.INFO, format="%(asctime)s - %(message)s")

def load_file(file_path):
    """Load lines from a file."""
    if os.path.exists(file_path):
        with open(file_path, 'r') as f:
            return [line.strip() for line in f.readlines() if line.strip()]
    return []

def save_file(file_path, lines):
    """Save lines to a file."""
    with open(file_path, 'w') as f:
        f.write('\n'.join(lines))

def generate_private_key():
    """Generate a random Ethereum private key."""
    return binascii.hexlify(os.urandom(32)).decode('utf-8')

def private_to_public(private_key):
    """Convert a private key to a public key."""
    private_key_bytes = binascii.unhexlify(private_key)
    eth_private_key = keys.PrivateKey(private_key_bytes)
    return eth_private_key.public_key.to_checksum_address()

def check_balance(web3, address):
    """Check the balance of an Ethereum address."""
    try:
        balance = web3.eth.get_balance(address)
        return Web3.from_wei(balance, 'ether')
    except Exception as e:
        logging.error(f"Error checking balance for {address}: {e}")
        return None

def main():
    txt_folder = 'txt'
    os.makedirs(txt_folder, exist_ok=True)

    eth_txt = os.path.join(txt_folder, 'eth.txt')
    infura_txt = os.path.join(txt_folder, 'infura.txt')
    eth_tried_txt = os.path.join(txt_folder, 'eth_tried.txt')
    eth_winner_txt = os.path.join(txt_folder, 'eth_winner.txt')

    eth_addresses = load_file(eth_txt)
    infura_apis = load_file(infura_txt)
    tried_keys = set(load_file(eth_tried_txt))

    if not infura_apis:
        logging.error("No Infura APIs available in infura.txt.")
        return

    infura_connections = [Web3(Web3.HTTPProvider(api_url)) for api_url in infura_apis]

    # Run indefinitely until manually stopped
    while True:
        try:
            private_key = generate_private_key()

            if private_key in tried_keys:
                continue

            public_key = private_to_public(private_key)
            logging.info(f"Generated Wallet - Private Key: {private_key}, Public Key: {public_key}")

            balance_checked = False
            for web3 in infura_connections:
                if web3.is_connected():
                    balance = check_balance(web3, public_key)
                    if balance is not None:
                        balance_checked = True
                        logging.info(f"Balance for {public_key}: {balance} ETH")
                        if balance > 0:
                            winner_info = f"Private Key: {private_key}, Public Key: {public_key}, Balance: {balance} ETH"
                            logging.info(f"Winner found: {winner_info}")
                            save_file(eth_winner_txt, load_file(eth_winner_txt) + [winner_info])
                        break
                else:
                    logging.warning("Failed to connect to Infura API.")

            if not balance_checked:
                logging.warning("No working Infura API available.")

            # Add the private key to tried_keys and save it immediately
            tried_keys.add(private_key)
            save_file(eth_tried_txt, list(tried_keys))

            # Short delay to prevent overloading APIs
            sleep(0.1)  # Adjust as needed for performance
        except Exception as e:
            logging.error(f"Unexpected error: {e}")

if __name__ == "__main__":
    main()
