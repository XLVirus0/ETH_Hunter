from flask import Flask, request, jsonify
import telegram
from telegram.ext import Updater, CommandHandler

# Replace with your token
TOKEN = "7789777922:AAHRjmn-Zqfy1k8xiIuXhwFZNZe8fsLxARM"
chat_id = 1847793495  # Replace with your chat ID

# Initialize Flask app
app = Flask(__name__)

# Create a bot instance
bot = telegram.Bot(token=TOKEN)

def start(update, context):
    """Handle the /start command."""
    update.message.reply_text("Welcome! This bot will notify you of winner wallets.")

@app.route("/send_message", methods=["POST"])
def send_message():
    """Receive a message from another service and send it via Telegram."""
    try:
        message = request.json.get('message')
        if message:
            bot.send_message(chat_id=chat_id, text=message)
            return jsonify({"status": "success", "message": "Message sent successfully!"}), 200
        else:
            return jsonify({"status": "error", "message": "No message provided!"}), 400
    except Exception as e:
        return jsonify({"status": "error", "message": str(e)}), 500

def main():
    """Start the Telegram bot and the Flask server."""
    # Set up the Telegram bot
    updater = Updater(TOKEN, use_context=True)
    dp = updater.dispatcher
    dp.add_handler(CommandHandler("start", start))

    # Start the Flask web server (in a separate thread)
    app.run(host="0.0.0.0", port=5000)

if __name__ == "__main__":
    main()
